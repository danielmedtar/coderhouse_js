let productos = [
    {id: 1, nombre: "lenovo14", tipo: "Notebooks", marca: "lenovo", desc: "LENOVO 14 Intel", precio: 60000, img: 'img/pc1.lenovo-14-intel.webp'},
    {id: 2, nombre: "lenovoPad", tipo: "Notebooks", marca: "lenovo", desc: "LENOVO IDEA PAD 3", precio: 80000, img: 'img/pc2.lenovo-ideapad-3.webp'},
    {id: 3, nombre: "lenovoP15", tipo: "Notebooks", marca: "lenovo", desc: "Lenovo P15", precio: 50000, img: 'img/pc3.lenovo-p15.webp'},
    {id: 4, nombre: "estudio", tipo: "Notebooks", marca: "cx", desc: "CX PC ESTUDIO A3000. AMD", precio: 120000, img: 'img/pc4.compu_escritorio1.jpg'},
    {id: 5, nombre: "comboJ7", tipo: "Notebooks", marca: "exo", desc: "EXO COMBO READY J7-V1345Y", precio: 110000, img: 'img/pc5.compu_escritorio2.jpg'},
    {id: 6, nombre: "allInOne", tipo: "Notebooks", marca: "hp", desc: "HP All in One 20-c307la", precio: 75000, img: 'img/pc6.compu_escritorio3.jpg'},
    {id: 7, nombre: "javascript", tipo: "Remeras", marca: "dev", desc: "JAVASCRIPT", precio: 3500, img: 'img/remera1.jpg'},
    {id: 8, nombre: "html", tipo: "Remeras", marca: "dev", desc: "HTML", precio: 2000, img: 'img/remera2.jpg'},
    {id: 9, nombre: "sass", tipo: "Remeras", marca: "dev", desc: "SASS", precio: 2500, img: 'img/remera3.jpg'},
    {id: 10, nombre: "angular", tipo: "Remeras", marca: "dev", desc: "ANGULAR", precio: 3000, img: 'img/remera4.jpg'},
    {id: 11, nombre: "node", tipo: "Remeras", marca: "dev", desc: "NODE.JS", precio: 1500, img: 'img/remera5.jpg'},
    {id: 12, nombre: "github", tipo: "Remeras", marca: "dev", desc: "GITHUB", precio: 4000, img: 'img/remera6.jpg'}
]